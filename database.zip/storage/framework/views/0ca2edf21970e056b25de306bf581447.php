<?php $__env->startSection('titulo', 'Mis Pedidos'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container-fluid bg-light-profile py-5">
    <div class="container container-profile">
        <div class="row g-4">
            
            <div class="col-md-4 col-lg-3">
                <div class="d-flex align-items-center gap-3 mb-4 ps-2">
                    <div class="avatar-circle">
                        <i class="ti ti-user fs-2 text-secondary"></i>
                    </div>
                    <h5 class="mb-0 fw-normal text-dark">Hola!</h5>
                </div>

                <div class="d-flex flex-column sidebar-profile-menu gap-1">
                    <a href="/perfil" class="sidebar-link">Perfil</a>
                    <a href="/historial" class="sidebar-link active">Pedidos</a>
                    <a href="/favoritos" class="sidebar-link">Lista de deseos</a>
                    
                    <a href="<?php echo e(route('logout')); ?>" class="sidebar-link text-muted mt-2"
                       onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        Salir
                    </a>
                </div>
            </div>

            <div class="col-md-8 col-lg-9">
    <h2 class="fw-bold text-dark mb-4 profile-main-title">Pedidos</h2>

    <?php if($pedidos->isEmpty()): ?>
        <div class="text-center py-5 bg-white rounded-4 shadow-sm">
            <i class="ti ti-receipt fs-1 text-muted mb-3 d-block"></i>
            <p class="text-muted mb-0">Aún no realizaste ninguna compra.</p>
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card border-0 shadow-sm rounded-4 bg-white p-4 mb-4">
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center border-bottom pb-3 mb-3">
                    <div>
                       <span class="fw-bold text-success fs-5">
                             <?php echo e($pedido->status == 'entregado' ? 'Llegó el ' : 'Realizado el '); ?> 
                             <?php echo e(\Carbon\Carbon::parse($pedido->created_at)->locale('es')->isoFormat('D [de] MMMM')); ?>

                        </span>
                        <span class="d-block text-muted small mt-1">Pedido #<?php echo e($pedido->id); ?> · <?php echo e($pedido->productos->count()); ?> producto(s)</span>
                    </div>
                    <span class="fw-bold text-dark fs-5 mt-2 mt-md-0">Total: $<?php echo e(number_format($pedido->total, 2, ',', '.')); ?></span>
                </div>

                <?php $__currentLoopData = $pedido->productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('productos.detalle', $prod->id)); ?>" class="text-decoration-none d-flex align-items-center gap-3 mb-3 p-2 rounded-3 product-history-item">
        
        <div class="border rounded-3 p-1 bg-light d-flex align-items-center justify-content-center" style="width: 75px; height: 75px; min-width: 75px; overflow: hidden;">
            <?php
                // TRUCO SALVAVIDAS: Si en la base de datos solo se guardó el nombre del archivo (ej: "camara.png"), 
                // le agregamos el prefijo de la carpeta automáticamente para que no salga rota.
                $rutaImagen = (strpos($prod->imagen, 'images/') === 0) ? $prod->imagen : 'images/img-products/' . $prod->imagen;
            ?>
            <img src="<?php echo e(asset($rutaImagen)); ?>" class="img-fluid" style="max-height: 100%; max-width: 100%; object-fit: contain;" alt="<?php echo e($prod->nombre); ?>">
        </div>
        
        <div class="flex-grow-1">
            <h6 class="mb-1 fw-bold text-dark text-truncate-2 product-title-hover" style="font-size: 0.95rem; line-height: 1.3;">
                <?php echo e($prod->nombre); ?>

            </h6>
            <span class="text-muted small d-block">Cantidad: <?php echo e($prod->pivot->cantidad ?? 1); ?></span>
        </div>
        
        <div class="pe-2 text-secondary d-none d-md-block">
            <i class="ti ti-chevron-right fs-4"></i>
        </div>
    </a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pc\Herd\proyecto-tienda-oga\resources\views/historial.blade.php ENDPATH**/ ?>