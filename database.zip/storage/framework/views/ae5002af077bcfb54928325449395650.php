<?php $__env->startSection('titulo', $titulo); ?>

<?php $__env->startSection('contenido'); ?>

<div class="container my-5">
    
    <?php if(session('success')): ?>
        <div class="alert alert-success p-2 small shadow-sm"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger p-2 small shadow-sm"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="row mb-4">
        <div class="col-12">
            <h1 class="fw-bold"><?php echo e($titulo); ?></h1>
            <p class="text-muted">Explorá nuestros artículos seleccionados con la mejor tecnología y calidad de Tienda OGA.</p>
            <hr>
        </div>
    </div>

    <div class="row">
        
        <?php $__empty_1 = true; $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                
                <a href="<?php echo e(route('productos.detalle', $prod->id)); ?>" class="text-decoration-none text-dark">
                    <div class="card h-100 shadow-sm border-0 position-relative content-tarjeta">
                        
                        <?php if($prod->porcentaje_descuento > 0): ?>
                            <span class="badge bg-danger position-absolute top-0 start-0 m-3 fs-6 shadow-sm">
                                <?php echo e($prod->porcentaje_descuento); ?>% OFF
                            </span>
                        <?php endif; ?>

                        <img src="<?php echo e(asset('images/img-products/' . $prod->imagen)); ?>" class="card-img-top p-3 imagen-catalogo-ajustada" alt="<?php echo e($prod->nombre); ?>" style="height: 200px; object-fit: contain;">
                        
                        <div class="card-body border-top d-flex flex-column justify-content-between">
                            <div>
                                <h5 class="card-title fw-bold text-truncate mb-1" title="<?php echo e($prod->nombre); ?>"><?php echo e($prod->nombre); ?></h5>
                                <p class="card-text text-muted small"><?php echo e(Str::limit($prod->descripcion, 50)); ?></p>
                            </div>

                            <div class="mt-2">
                                <?php if($prod->porcentaje_descuento > 0): ?>
                                    <span class="text-muted text-decoration-line-through small d-block">
                                        $<?php echo e(number_format($prod->precio * 1.3, 0, ',', '.')); ?>

                                    </span>
                                <?php endif; ?>
                                
                                <h4 class="fw-bold text-success mb-0">$<?php echo e(number_format($prod->precio, 0, ',', '.')); ?></h4>
                            </div>
                        </div>
                    </div>
                </a>
                
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5">
                <i class="ti ti-box-off display-3 text-muted mb-3"></i>
                <h4 class="text-muted">No se encontraron artículos en esta sección por el momento.</h4>
                <a href="<?php echo e(route('inicio')); ?>" class="btn btn-outline-primary mt-3 fw-bold">Volver a la Portada</a>
            </div>
        <?php endif; ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pc\Herd\proyecto-tienda-oga\resources\views/catalogo.blade.php ENDPATH**/ ?>