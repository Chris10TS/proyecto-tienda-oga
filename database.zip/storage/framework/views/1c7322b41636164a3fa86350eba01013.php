<?php $__env->startSection('titulo', 'Iniciar Sesión'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="container-fluid bg-white login-wrapper">
    <div class="container py-5 login-container">
        <div class="row justify-content-center pt-lg-4 position-relative">
            
            <div class="col-md-6 pe-md-5 text-center border-end border-secondary-subtle align-self-start col-login-left">
                <div class="title-container mb-4">
                    <h3 class="fw-bolder text-dark custom-title m-0">
                        Elegí una opción para<br>ingresar
                    </h3>
                </div>
                
                <div class="d-flex flex-column align-items-center mb-4">
                    <button id="btn-flujo-codigo" onclick="mostrarFlujo('codigo')" class="btn btn-outline-primary py-2.5 rounded-pill fw-bold shadow-none bg-white btn-custom-width btn-flow-toggle">
                        Recibir código de acceso por e-mail
                    </button>

                    <button id="btn-flujo-password" onclick="mostrarFlujo('password')" class="btn btn-outline-primary py-2.5 rounded-pill fw-bold shadow-none bg-white btn-custom-width btn-flow-toggle d-none">
                        Entrar con e-mail y contraseña
                    </button>
                </div>
            </div>

            <div class="col-md-6 ps-md-5 text-center mt-5 mt-md-0 align-self-start">
                
                <div id="vista-password" class="mx-auto form-box">
                    <div class="title-container mb-4">
                        <h3 class="fw-bolder text-dark custom-title m-0">
                            Entrar con e-mail y<br>contraseña
                        </h3>
                    </div>

                    <form method="POST" action="<?php echo e(route('login')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <input type="email" name="email" class="form-control form-control-lg bg-white rounded-pill px-4 login-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   placeholder="Ej.: ejemplo@mail.com" value="<?php echo e(old('email')); ?>" required autofocus>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback text-start ps-3"><strong><?php echo e($message); ?></strong></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="mb-2 position-relative">
                            <input type="password" name="password" class="form-control form-control-lg bg-white rounded-pill px-4 login-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                   placeholder="Ingrese su contraseña" required>
                            <i class="ti ti-eye text-secondary position-absolute top-50 end-0 translate-middle-y pe-4 fs-5 btn-toggle-eye"></i>
                        </div>

                        <?php if(Route::has('password.request')): ?>
                            <div class="text-end mb-4 pe-2">
                                <a class="small text-decoration-underline fw-bold link-forgot" href="<?php echo e(route('password.request')); ?>">
                                    Olvidé mi contraseña
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-primary btn-lg fw-bold text-white rounded-pill fs-6 py-2.5 shadow-none btn-submit-login">
                                Entrar
                            </button>
                        </div>
                    </form>
                </div>

                <div id="vista-codigo" class="mx-auto form-box d-none">
                    <div class="title-container mb-4">
                        <h3 class="fw-bolder text-dark custom-title m-0">
                            Recibir código de acceso por<br>e-mail
                        </h3>
                    </div>

                    <form method="POST" action="<?php echo e(route('login')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <input type="email" name="email_codigo" class="form-control form-control-lg bg-white rounded-pill px-4 login-input" 
                                   placeholder="Ej.: ejemplo@mail.com" required>
                        </div>

                        <div class="d-grid mb-4">
                            <button type="submit" class="btn btn-primary btn-lg fw-bold text-white rounded-pill fs-6 py-2.5 shadow-none btn-submit-login">
                                Enviar
                            </button>
                        </div>
                    </form>
                </div>

                <div class="text-center mt-3">
                    <p class="small mb-0 fw-bold">
                        <a href="<?php echo e(route('register')); ?>" class="text-decoration-underline link-register">
                            ¿No tiene una cuenta? Regístrese
                        </a>
                    </p>
                </div>

            </div>

        </div>
    </div>
</div>

<script>
function mostrarFlujo(flujo) {
    const btnCodigo = document.getElementById('btn-flujo-codigo');
    const btnPassword = document.getElementById('btn-flujo-password');
    const vistaPassword = document.getElementById('vista-password');
    const vistaCodigo = document.getElementById('vista-codigo');

    if (flujo === 'codigo') {
        vistaPassword.classList.add('d-none');
        btnCodigo.classList.add('d-none');
        vistaCodigo.classList.remove('d-none');
        btnPassword.classList.remove('d-none');
    } else {
        vistaCodigo.classList.add('d-none');
        btnPassword.classList.add('d-none');
        vistaPassword.classList.remove('d-none');
        btnCodigo.classList.remove('d-none');
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pc\Herd\proyecto-tienda-oga\resources\views/auth/login.blade.php ENDPATH**/ ?>