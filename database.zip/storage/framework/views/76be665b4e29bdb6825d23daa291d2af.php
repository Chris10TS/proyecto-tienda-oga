<?php $__env->startSection('titulo', $producto->nombre); ?>

<?php $__env->startSection('contenido'); ?>

<div class="container mt-4">

    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/inicio">Inicio</a></li>
            <li class="breadcrumb-item"><a href="/catalogo">Catálogo</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($producto->nombre); ?></li>
        </ol>
    </nav>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show fw-bold mb-4 shadow-sm" role="alert">
            <i class="ti ti-circle-x-filled"></i> <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row mb-5">

        <div class="col-md-5">
            <div class="card p-3 text-center">
                <img src="<?php echo e(asset('images/img-products/' . $producto->imagen)); ?>" class="img-fluid rounded imagen-contenida" alt="<?php echo e($producto->nombre); ?>">
            </div>
        </div>

        <div class="col-md-4">
            <span class="badge bg-success mb-2">MÁS VENDIDO</span>
            <h1 class="fs-4 fw-bold"><?php echo e($producto->nombre); ?></h1>

            <div class="d-flex align-items-center gap-2 mb-3">
                <span class="text-warning fs-5">★★★★☆</span>
                <span class="text-muted">(128 opiniones)</span>
            </div>

            <p class="text-muted text-decoration-line-through mb-0">$<?php echo e(number_format($producto->precio * 1.3, 0, ',', '.')); ?></p>
            
            <div class="d-flex align-items-center gap-2 mb-1">
                <span class="fs-2 fw-bold">$<?php echo e(number_format($producto->precio, 0, ',', '.')); ?></span>
                <span class="badge bg-success fs-6">30% OFF</span>
            </div>
            
            <p class="text-muted mb-3">6 cuotas de $<?php echo e(number_format($producto->precio / 6, 0, ',', '.')); ?> sin interés</p>

            <ul class="list-unstyled mb-3">
                <li><i class="ti ti-check"></i> Alta calidad y rendimiento garantizado</li>
                <li><i class="ti ti-check"></i> Componentes Premium Tienda OGA</li>
                <li><i class="ti ti-check"></i> Conectividad y facilidad de uso</li>
                <li><i class="ti ti-check"></i> Diseño ergonómico y resistente</li>
            </ul>

            <?php if($producto->stock > 0): ?>
                <p class="text-success fw-bold"><i class="ti ti-circle-check"></i> Stock disponible (<?php echo e($producto->stock); ?> unidades)</p>
            <?php else: ?>
                <p class="text-danger fw-bold"><i class="ti ti-circle-x"></i> Sin stock de momento</p>
            <?php endif; ?>
        </div>

        <div class="col-md-3">
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->rol === 'admin'): ?>

                    <div class="card p-3 text-center bg-white rounded shadow-sm border-0">
                        <p class="fw-bold mb-3 d-flex align-items-center justify-content-center gap-2">
                             MODO ADMINISTRADOR
                        </p>
                        
                    <a href="<?php echo e(route('admin.productos.edit', $producto->id)); ?>" class="btn btn-sm w-100 mb-2 fw-bold" style="color: #f07143; border: 2px solid #f07143; background-color: transparent; transition: all 0.2s ease;">
                       <i class="ti ti-edit me-1"></i> Editar Producto
                    </a>

                    <form action="<?php echo e(route('admin.productos.destroy', $producto->id)); ?>" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas dar de baja este producto?');">
                         <?php echo csrf_field(); ?>
                         <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-sm w-100 fw-bold" style="color: #f07143; border: 2px solid #f07143; background-color: transparent; transition: all 0.2s ease;">
                       <i class="ti ti-trash me-1"></i> Dar de Baja
                       </button>
                     </form>

                        <div class="border-top pt-3 mt-3 text-muted" style="font-size: 0.85rem;">
                            <p class="mb-1">Código OGA: <strong>#00<?php echo e($producto->id); ?></strong></p>
                            <p class="mb-0">Stock disponible: <strong><?php echo e($producto->stock); ?> unidades</strong></p>
                        </div>
                    </div>
                <?php else: ?>

                    <div class="card p-3 contenedor-estatico shadow-sm rounded bg-white border-0">
                        <p class="text-success fw-bold mb-1"><i class="ti ti-truck-delivery"></i> Envío gratis en Corrientes</p>
                        <p class="text-muted small mb-3">Envío gratis a partir de $100.000 al resto del país</p>

                        <form action="<?php echo e(route('carrito.agregar', $producto->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <label class="form-label fw-bold small">Cantidad</label>
                            <select name="cantidad" class="form-select mb-3">
                                <option value="1">1 unidad</option>
                                <option value="2">2 unidades</option>
                                <option value="3">3 unidades</option>
                                <option value="4">4 unidades</option>
                                <option value="5">5 unidades</option>
                            </select>

                            <?php if($producto->stock > 0): ?>
                                <button type="submit" formaction="<?php echo e(route('carrito.comprarAhora', $producto->id)); ?>" class="btn btn-warning w-100 mb-2 fw-bold text-dark shadow-sm">
                                    Comprar ahora
                                </button>
                                
                                <button type="submit" class="btn btn-outline-dark w-100 mb-3 fw-bold">
                                    <i class="ti ti-shopping-cart"></i> Agregar al carrito
                                </button>
                                
                                <p class="text-muted small mb-0">Disponibles: <span class="fw-bold"><?php echo e($producto->stock); ?> unidades</span></p>
                            <?php else: ?>
                                <button class="btn btn-secondary w-100 mb-3" disabled>
                                    <i class="ti ti-shopping-cart-off"></i> Sin Stock Disponible
                                </button>
                            <?php endif; ?>
                        </form>

                        <?php
                            $esFavorito = Auth::user()->favoritos()->where('producto_id', $producto->id)->exists();
                        ?>
                        
                        <form action="<?php echo e(route('productos.favorito', $producto->id)); ?>" method="POST" class="mt-2">
                         <?php echo csrf_field(); ?>
                        <button type="submit" class="btn w-100 btn-oga-naranja shadow-sm">
                           <?php if($esFavorito): ?>
                           <i class="ti ti-heart-filled me-1"></i> Quitar de Favoritos
                           <?php else: ?>
                           <i class="ti ti-heart me-1"></i> Añadir a Favoritos
                           <?php endif; ?>
                           </button>
                        </form>

                        <div class="border-top pt-3 mt-3 text-muted">
                            <p class="small mb-1">Devoluciones hasta 30 días</p>
                            <p class="small mb-1">Garantía 6 meses</p>
                            <p class="small mb-0">Compra segura</p>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else: ?>
            
                <div class="card p-3 contenedor-estatico shadow-sm rounded bg-white border-0">
                    <p class="text-success fw-bold mb-1"><i class="ti ti-truck-delivery"></i> Envío gratis en Corrientes</p>
                    <p class="text-muted small mb-3">Envío gratis a partir de $100.000 al resto del país</p>

                    <form action="<?php echo e(route('carrito.agregar', $producto->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <label class="form-label fw-bold small">Cantidad</label>
                        <select name="cantidad" class="form-select mb-3">
                            <option value="1">1 unidad</option>
                            <option value="2">2 unidades</option>
                            <option value="3">3 unidades</option>
                            <option value="4">4 unidades</option>
                            <option value="5">5 unidades</option>
                        </select>

                        <?php if($producto->stock > 0): ?>
                            <button type="submit" formaction="<?php echo e(route('carrito.comprarAhora', $producto->id)); ?>" class="btn btn-warning w-100 mb-2 fw-bold text-dark shadow-sm">
                                Comprar ahora
                            </button>
                            
                            <button type="submit" class="btn btn-outline-dark w-100 mb-3 fw-bold">
                                <i class="ti ti-shopping-cart"></i> Agregar al carrito
                            </button>
                            
                            <p class="text-muted small mb-0">Disponibles: <span class="fw-bold"><?php echo e($producto->stock); ?> unidades</span></p>
                        <?php else: ?>
                            <button class="btn btn-secondary w-100 mb-3" disabled>
                                <i class="ti ti-shopping-cart-off"></i> Sin Stock Disponible
                            </button>
                        <?php endif; ?>
                    </form>

                    <div class="text-center mt-3">
                        <a href="<?php echo e(route('login')); ?>" class="text-danger small fw-bold text-decoration-none">
                            <i class="ti ti-heart"></i> Ingresá para guardar en favoritos
                        </a>
                    </div>

                    <div class="border-top pt-3 mt-3 text-muted">
                        <p class="small mb-1">Devoluciones hasta 30 días</p>
                        <p class="small mb-1">Garantía 6 meses</p>
                        <p class="small mb-0">Compra segura</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

    </div>

    <div class="row mb-5">
        <div class="col-12">
            <div class="cardP p-4 bg-white rounded shadow-sm">
                <h3 class="fw-bold mb-3">Descripción del producto</h3>
                <p><?php echo e($producto->descripcion); ?></p>
                
                <h5 class="mt-4">Especificaciones técnicas</h5>
                <table class="table table-bordered mt-2">
                    <tbody>
                        <tr><td><strong>Producto</strong></td><td><?php echo e($producto->nombre); ?></td></tr>
                        <tr><td><strong>Categoría</strong></td><td><?php echo e($producto->categoria->nombre); ?></td></tr>
                        <tr><td><strong>Código de Identificación</strong></td><td>OGA-#00<?php echo e($producto->id); ?></td></tr>
                        <tr><td><strong>Garantía oficial</strong></td><td>6 meses</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="row mb-5">
        <div class="col-12">
            <div class="card4 p-4 bg-white rounded shadow-sm">
                <h3 class="fw-bold mb-4">Opiniones de clientes</h3>
                
                <?php $__empty_1 = true; $__currentLoopData = $producto->reseñas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reseña): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-bottom pb-3 mb-3">
                        <div class="d-flex justify-content-between">
                            <strong><?php echo e($reseña->user->name); ?></strong>
                            <span class="text-muted small"><?php echo e($reseña->created_at->format('d/m/Y')); ?></span>
                        </div>
                        <span class="text-warning">
                            <?php echo e(str_repeat('★', $reseña->estrellas)); ?><?php echo e(str_repeat('☆', 5 - $reseña->estrellas)); ?>

                        </span>
                        <p class="mt-1 mb-0"><?php echo e($reseña->comentario); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted small mb-4">Este producto todavía no tiene opiniones escritas.</p>
                <?php endif; ?>

                
                <?php if(Auth::check() && Auth::user()->rol !== 'admin'): ?>
                    <?php
                        $haComprado = \App\Models\Pedido::where('user_id', Auth::id())
                            ->where('estado', 'pagado')
                            ->whereHas('productos', function($query) use ($producto) {
                                $query->where('producto_id', $producto->id);
                            })->exists();
                    ?>

                    <?php if($haComprado): ?>
                        <div class="bg-light p-3 rounded border mt-4">
                            <h5 class="fw-bold text-dark mb-3"><i class="ti ti-message-2"></i> Dejanos tu opinión sobre el producto</h5>
                            
                            <form action="<?php echo e(route('productos.opinor', $producto->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label class="form-label fw-bold small">Calificación (Estrellas)</label>
                                    <select name="estrellas" class="form-select bg-white" style="max-width: 150px;" required>
                                        <option value="5">★★★★★ (5)</option>
                                        <option value="4">★★★★☆ (4)</option>
                                        <option value="3">★★★☆☆ (3)</option>
                                        <option value="2">★★☆☆• (2)</option>
                                        <option value="1">★☆☆☆☆ (1)</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-bold small">Tu comentario</label>
                                    <textarea name="comentario" class="form-control bg-white" rows="3" placeholder="Contanos qué te pareció el artículo..." required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary fw-bold btn-sm px-4 shadow-sm">Publicar Reseña</button>
                            </form>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Pc\Herd\proyecto-tienda-oga\resources\views/productos/detalle.blade.php ENDPATH**/ ?>